﻿namespace MyPackage
{
    public class Demo
    {
        public virtual string Hello(string name)
        {
            return $"Hello {name}";
        }
    }
}
